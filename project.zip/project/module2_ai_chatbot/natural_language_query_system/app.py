import streamlit as st
import pandas as pd
from nlp_processor import process_query
from data_processor import execute_query
from response_generator import generate_response
from modules.file_upload import handle_file_upload
import io
import plotly.express as px

def initialize_chat():
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []
    if "queued_query" not in st.session_state:
        st.session_state.queued_query = None
    if "df" not in st.session_state:
        st.session_state.df = None
    if "data_loaded" not in st.session_state:
        st.session_state.data_loaded = False

def generate_suggestions(df: pd.DataFrame, chat_history: list = None) -> list:
    """Generates dynamic query suggestions based on the provided dataset structures and current context."""
    suggestions = []
    
    # Identify Numeric and Categorical columns safely using Pandas dtypes
    numeric_cols = df.select_dtypes(include=['int64', 'float64', 'int32', 'float32', 'int', 'float']).columns.tolist()
    categorical_cols = df.select_dtypes(include=['object', 'category', 'string']).columns.tolist()
    
    # Separate explicit time/date columns conceptually
    time_cols = [col for col in df.columns if 'year' in col.lower() or 'date' in col.lower() or 'time' in col.lower()]
    
    # Filter true metrics vs categories
    metrics = [col for col in numeric_cols if col not in time_cols][:3]
    categories = [col for col in categorical_cols if col not in time_cols][:3]

    if not metrics:
        return ["Show all data points"]
        
    primary_metric = metrics[0]
    
    # --- CONTEXT-AWARE RECOMMENDATIONS ---
    if chat_history and len(chat_history) > 0:
        # Find last assistant message that has parsed_query
        for msg in reversed(chat_history):
            if msg["role"] == "assistant" and msg.get("parsed_query"):
                last_intent = msg["parsed_query"].get("intent")
                last_metric = msg["parsed_query"].get("metric") or primary_metric
                
                if last_intent == "trend":
                    suggestions.append(f"Compare {last_metric.lower()} across different categories")
                    suggestions.append(f"Which category has the highest {last_metric.lower()}?")
                elif last_intent == "comparison":
                    suggestions.append(f"Show the historical trend for {last_metric.lower()}")
                    if len(metrics) > 1:
                        suggestions.append(f"How does {last_metric.lower()} compare to {metrics[1].lower()}?")
                elif last_intent in ["profiling", "quality" , "summary"]:
                    suggestions.append(f"Show {last_metric.lower()} trend over time")
                break
                
    # --- FALLBACK / DEFAULT RECOMMENDATIONS ---
    # We add basics if we have room
    if len(suggestions) < 3:
        if f"What is the total {primary_metric.lower()}?" not in suggestions:
            suggestions.append(f"What is the total {primary_metric.lower()}?")
        if categories and f"Compare {primary_metric.lower()} across {categories[0].lower()}s" not in suggestions:
            suggestions.append(f"Compare {primary_metric.lower()} across {categories[0].lower()}s")
        if time_cols and f"Show {primary_metric.lower()} trend over {time_cols[0].lower()}s" not in suggestions:
            suggestions.append(f"Show {primary_metric.lower()} trend over {time_cols[0].lower()}s")
         
    return list(dict.fromkeys(suggestions))[:5] # Deduplicate and limit to 5



def render_chart(parsed_query: dict, data):
    """Renders visual charts natively based on explicit NLP intents."""
    if data is None:
        return
        
    intent = parsed_query.get("intent")
    
    if intent == "profiling" and isinstance(data, dict):
        st.subheader("Dataset Profile")
        st.write(f"**Rows:** {data.get('total_rows')}  |  **Columns:** {data.get('total_cols')}")
        st.dataframe(data.get("statistics") if data.get("statistics") is not None else pd.DataFrame())
        return
        
    if intent == "quality" and isinstance(data, dict):
        st.subheader("🛠️ Data Quality Overview")
        col1, col2, col3, col4 = st.columns(4)
        col1.metric("Quality Score", f"{data.get('score')}/100")
        col2.metric("Missing Values", data.get("missing_total"))
        col3.metric("Duplicates", data.get("duplicate_rows"))
        col4.metric("Outliers", data.get("outliers_total"))
        
        st.divider()
        col_left, col_right = st.columns(2)
        
        with col_left:
            st.markdown("##### Missing Values Breakdown")
            missing_df = data.get("missing_summary").reset_index()
            if not missing_df.empty:
                missing_df.rename(columns={'index': 'Feature'}, inplace=True)
                fig_miss = px.bar(missing_df, x='Feature', y='Missing Values', template="plotly_dark", color_discrete_sequence=["#EF4444"])
                st.plotly_chart(fig_miss, use_container_width=True)
            else:
                st.success("No missing values detected! 🙌")
                
        with col_right:
            st.markdown("##### Outlier Distribution")
            raw_df = st.session_state.df
            if raw_df is not None:
                numeric_col = raw_df.select_dtypes(include=['number']).columns[0]
                fig_box = px.box(raw_df, y=numeric_col, template="plotly_dark", points="outliers", color_discrete_sequence=["#3B82F6"])
                st.plotly_chart(fig_box, use_container_width=True)
        return
        
    if not isinstance(data, pd.DataFrame) or data.empty:
        return
        
    try:
        # Identify Column Types
        numeric_cols = data.select_dtypes(include=['number']).columns.tolist()
        categorical_cols = data.select_dtypes(include=['object', 'category', 'string']).columns.tolist()
        time_cols = [col for col in data.columns if 'year' in col.lower() or 'date' in col.lower() or 'time' in col.lower()]
        
        # Clean overlapping
        numeric_cols = [c for c in numeric_cols if c not in time_cols]
        categorical_cols = [c for c in categorical_cols if c not in time_cols]
        
        target_metric = parsed_query.get("metric")
        if target_metric:
            match = [col for col in numeric_cols if col.lower() == target_metric.lower()]
            y_col = match[0] if match else (numeric_cols[0] if numeric_cols else None)
        else:
            y_col = numeric_cols[0] if numeric_cols else None
            
        if not y_col:
            st.info("Missing a numeric metric to visually plot.")
            return

        if intent == "trend":
            x_col = time_cols[0] if time_cols else (categorical_cols[0] if categorical_cols else None)
            if x_col:
                chart_data = data.groupby(x_col)[y_col].sum().reset_index()
                with st.container():
                    st.markdown(f"### 📈 {y_col} Trajectory")
                    fig = px.line(chart_data, x=x_col, y=y_col, markers=True, template="plotly_dark", color_discrete_sequence=["#A855F7"])
                    st.plotly_chart(fig, use_container_width=True)
            else:
                st.line_chart(data[y_col])
                
        elif intent == "comparison":
            x_col = categorical_cols[0] if categorical_cols else (time_cols[0] if time_cols else None)
            if x_col:
                chart_data = data.groupby(x_col)[y_col].sum().reset_index()
                with st.container():
                    st.markdown(f"### 📊 Comparing {y_col}")
                    col_bar, col_pie = st.columns(2)
                    with col_bar:
                        fig_bar = px.bar(chart_data, x=x_col, y=y_col, text_auto='.2s', template="plotly_dark", color_discrete_sequence=["#A855F7"])
                        st.plotly_chart(fig_bar, use_container_width=True)
                    with col_pie:
                        fig_pie = px.pie(chart_data, names=x_col, values=y_col, template="plotly_dark", hole=0.4, color_discrete_sequence=px.colors.sequential.Purples_r)
                        fig_pie.update_traces(textposition='inside', textinfo='percent+label')
                        st.plotly_chart(fig_pie, use_container_width=True)
                
                if len(numeric_cols) > 1:
                    y2_col = numeric_cols[1]
                    with st.container():
                        st.markdown(f"**Multi-Variate Segment: {y_col} vs {y2_col}**")
                        fig_scatter = px.scatter(data, x=y_col, y=y2_col, color=x_col, size=y_col, hover_data=[x_col], template="plotly_dark")
                        st.plotly_chart(fig_scatter, use_container_width=True)
            else:
                st.bar_chart(data[y_col])
                
    except Exception as e:
        st.info(f"Visual generation simplified due to dimension mapping: {e}")
        st.dataframe(data.head())

def main():
    st.set_page_config(page_title="Intelligent AI Query Sys", page_icon="🤖", layout="wide")
    
    # Inject Global CSS for the Black and Purple Theme
    st.markdown("""
        <style>
        /* DARK THEME BACKGROUND */
        .stApp { background-color: #0E1117 !important; }
        p, div, span, label { color: #E2E8F0; }
        h1, h2, h3, h4, h5, h6 { color: #A855F7 !important; }

        /* SIDEBAR STYLING */
        [data-testid="stSidebar"] { background-color: #12151B !important; }
        [data-testid="stSidebar"] h1, [data-testid="stSidebar"] h2 { color: #9333EA !important; }
        [data-testid="stSidebar"] p { color: #E2E8F0 !important; }
        [data-testid="stMetricValue"] { color: #A855F7 !important; }

        /* INPUT BOX STYLING */
        [data-testid="stChatInput"] {
            background-color: #1A1D24 !important;
            border: 2px solid #7C3AED !important;
            border-radius: 20px !important;
            padding: 5px !important;
        }
        [data-testid="stChatInput"] textarea { color: #FFFFFF !important; caret-color: #A855F7 !important; }
        [data-testid="stChatInput"] button { color: #A855F7 !important; }

        /* CHAT UI STYLING & BUBBLES */
        div[data-testid="stChatMessage"] {
            padding: 1.25rem !important; border-radius: 18px !important; margin-bottom: 1.25rem !important;
        }
        div[data-testid="stChatMessage"]:has(div[data-testid="chatAvatarIcon-user"]) {
            flex-direction: row-reverse; text-align: right; background-color: #3B0764 !important;
        }
        div[data-testid="stChatMessage"]:has(div[data-testid="chatAvatarIcon-user"]) div[data-testid="chatMessageContent"] p { color: #FFFFFF !important; }
        div[data-testid="stChatMessage"]:has(div[data-testid="chatAvatarIcon-user"]) div[data-testid="chatAvatarIcon-user"] { margin-right: 0; margin-left: 1rem; }

        div[data-testid="stChatMessage"]:not(:has(div[data-testid="chatAvatarIcon-user"])) {
            background-color: #1A1D24 !important;
        }
        div[data-testid="stChatMessage"]:not(:has(div[data-testid="chatAvatarIcon-user"])) div[data-testid="chatMessageContent"] p {
            color: #D8B4FE !important;
        }

        .stButton>button { background-color: #7C3AED !important; color: white !important; border-radius: 8px !important; border: none !important; margin-bottom: 5px !important; }
        .stButton>button:hover { background-color: #9333EA !important; }
        </style>
    """, unsafe_allow_html=True)
    
    initialize_chat()
    
    st.title("🤖 AI-Powered Data Dashboard")
    st.markdown("Ask smart questions to instantly surface data trends, comparisons, and hidden insights without writing code.")
    
    with st.sidebar:
        st.header("📂 Data Upload")
        uploaded_df = handle_file_upload()
        df = st.session_state.df
        
        st.divider()
        st.header("💡 Dataset Insights")
        st.caption("Real-time summary of the active knowledge-base.")
        
        if df is not None:
            numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
            primary_metric = numeric_cols[0] if numeric_cols else None
            
            col1, col2 = st.columns(2)
            with col1: st.metric("Total Records", len(df))
            with col2: 
                if primary_metric:
                    st.metric(f"Avg {primary_metric}", f"{df[primary_metric].mean():,.0f}")
                else:
                    st.metric("Avg", "N/A")
            
            if primary_metric:
                st.metric(f"Total Overall {primary_metric}", f"{df[primary_metric].sum():,.0f}")
            
            st.divider()
            st.subheader("💡 Smart Suggestions")
            st.caption("Auto-generated based on dataset columns:")
            
            # Build dynamic lists based on context
            suggestions = generate_suggestions(df, st.session_state.chat_history)
            for sug in suggestions:
                # We add a hidden trigger button bridge for UI magic!
                if st.button(f"🔍 {sug.capitalize()}", use_container_width=True):
                    st.session_state.queued_query = sug
        else:
            st.info("Upload a dataset to see insights.")
                    
    for idx, chat in enumerate(st.session_state.chat_history):
        if chat["role"] == "user":
            with st.chat_message("user"):
                st.write(chat["content"])
        else:
            with st.chat_message("assistant", avatar="🤖"):
                st.markdown(chat["content"])
                if chat.get("parsed_query") and chat.get("data") is not None:
                    render_chart(chat["parsed_query"], chat["data"])

    input_query = st.chat_input("E.g., Compare sales across regions and show me the highest...")
    
    # Catching button-queued overrides directly via session_state!
    if st.session_state.queued_query:
        input_query = st.session_state.queued_query
        st.session_state.queued_query = None
        
    if input_query:
        with st.chat_message("user"):
            st.write(input_query)
        st.session_state.chat_history.append({"role": "user", "content": input_query})
        
        with st.chat_message("assistant", avatar="🤖"):
            with st.spinner("Analyzing dataset... 🔍"):
                if df is None:
                    final_response = "Please upload a dataset first!"
                    processed_result = {}
                    parsed_query = {}
                else:
                    parsed_query = process_query(input_query)
                    
                    # --- CONTEXT MEMORY INJECTION ---
                    # Check chat history to resolve missing parameters
                    if st.session_state.chat_history:
                        for msg in reversed(st.session_state.chat_history):
                            if msg["role"] == "assistant" and msg.get("parsed_query"):
                                last_query = msg["parsed_query"]
                                # Inject missing metric
                                if not parsed_query.get("metric") and last_query.get("metric"):
                                    parsed_query["metric"] = last_query.get("metric")
                                    parsed_query["_inferred_from_context"] = True
                                # If NLP couldn't find an intent on a short follow-up, use the last valid intent
                                if not parsed_query.get("intent") and last_query.get("intent"):
                                    parsed_query["intent"] = last_query.get("intent")
                                break
                    # --------------------------------

                    processed_result = execute_query(df, parsed_query)
                    final_response = generate_response(parsed_query, processed_result)
                
            st.markdown(final_response)
            render_chart(parsed_query, processed_result.get("data"))
                
        st.session_state.chat_history.append({
            "role": "assistant", 
            "content": final_response, 
            "data": processed_result.get("data"),
            "parsed_query": parsed_query
        })

if __name__ == "__main__":
    main()
