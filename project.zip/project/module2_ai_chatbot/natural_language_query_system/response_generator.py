import pandas as pd

def generate_response(parsed_query: dict, processed_data: dict) -> str:
    """
    Converts output into a human-readable conversational sentence based on the newly mapped intents.
    Returns dynamic text and specific emojis based on the intent context.
    """
    data = processed_data.get("data")
    intent = parsed_query.get("intent")
    
    # Safely handle null metrics and operations
    metric = parsed_query.get("metric")
    metric = metric.title() if metric else "Data"
    
    operation = parsed_query.get("operation")
    operation = operation.title() if operation else ""
    
    # Edge case handler for missing data
    if data is None:
        return "Sorry, I couldn't find matching data for your query. Please try tweaking your filters!"
        
    if processed_data.get("status") == "error":
        return f"😕 Oops, there was an issue processing that: {processed_data.get('message')}"
    
    # Formatting conversational outputs matched to emojis and visuals
    if intent == "profiling":
        return "Here is a profile summary of your dataset 📊"
    elif intent == "quality":
        return "Here is the data quality analysis 🛠️"
    elif intent == "comparison":
        return f"Here’s a comparison of {metric} across categories 📊"
    elif intent == "trend":
        return f"Here’s the {metric} trend over time 📈"
    elif intent == "aggregation":
        if not isinstance(data, pd.DataFrame):
            # Present single math metric results
            return f"📌 The {operation} for {metric} is {data:,.0f}!"
        else:
            return f"Here is the aggregated {metric} data 📌"
            
    # Default fallback
    if not isinstance(data, pd.DataFrame):
        return f"📌 The requested value is **{data}**."
    return f"Here is your raw {metric} data mapped out:"
