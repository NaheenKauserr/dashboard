import pandas as pd
from modules.data_profiling import generate_profile
from modules.data_quality import analyze_quality

def create_sample_dataset() -> pd.DataFrame:
    """Creates a robust sample fractional dataset suitable for charting."""
    return pd.DataFrame({
        "Year": [2022, 2022, 2023, 2023, 2024, 2024, 2024],
        "Region": ["North", "South", "East", "West", "India", "Europe", "USA"],
        "Sales": [150000, 220000, 180000, 290000, 500000, 300000, 450000],
        "Expenses": [100000, 120000, 110000, 140000, 400000, 250000, 350000],
        "Profit": [50000, 100000, 70000, 150000, 100000, 50000, 100000],
        "Revenue": [150000, 220000, 180000, 290000, 500000, 300000, 450000]
    })

def execute_query(df: pd.DataFrame, parsed_query: dict) -> dict:
    """
    Applies logic to the dataframe based on the parsed NLP query.
    If the intent requires raw data modeling (comparison/trend), passes it safely back to the generator.
    """
    filters = parsed_query.get("filters", {})
    metric = parsed_query.get("metric")
    if not metric: metric = "Sales" # default safety bound
    
    operation = parsed_query.get("operation")
    intent = parsed_query.get("intent")
    
    result = {
        "status": "success",
        "data": None,
        "message": ""
    }
    
    filtered_df = df.copy()
    
    # Check bounds against requested filters
    for key, val in filters.items():
        if key == "year" and 'Year' in filtered_df.columns:
            filtered_df = filtered_df[filtered_df['Year'].astype(str) == str(val)]
        elif key == "region" and 'Region' in filtered_df.columns:
            filtered_df = filtered_df[filtered_df['Region'].str.lower() == str(val).lower()]
            
    if filtered_df.empty:
        result["data"] = None
        result["message"] = f"Sorry, no specific datasets recorded for {str(filters)}."
        return result
        
    if intent == "profiling":
        return generate_profile(filtered_df)
        
    if intent == "quality":
        return analyze_quality(filtered_df)
        
    # Strictly bind metric calculations ONLY to datasets that possess that specific column
    target_col = None
    for col in filtered_df.columns:
        if col.lower() == metric.lower():
            target_col = col
            break
            
    if not target_col:
        result["status"] = "error"
        result["data"] = None
        result["message"] = f"The dataset doesn't have a column supporting '{metric}'."
        return result
            
    result["data"] = filtered_df
    
    # Do not flatten into a single math integer if they explicitly want to chart a trend vs comparison!
    if intent == "aggregation" and operation and target_col:
        try:
            val = None
            if operation == "sum":        val = filtered_df[target_col].sum()
            elif operation == "average":  val = filtered_df[target_col].mean()
            elif operation == "min":      val = filtered_df[target_col].min()
            elif operation == "max":      val = filtered_df[target_col].max()
            elif operation == "count":    val = len(filtered_df)
            
            result["data"] = val
            result["message"] = f"Successfully calculated {operation} for {metric}."
        except Exception as e:
            result["status"] = "error"
            result["message"] = f"Error performing operation: {e}"
    else:
        result["message"] = "Successfully filtered data for visual mapping."
        
    return result
