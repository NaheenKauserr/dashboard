# AI-Powered Data Dashboard 🤖

This project is an intelligent Natural Language Processing (NLP) chatbot and data analytics dashboard built with Python and Streamlit. It allows users to upload datasets and ask natural language questions (e.g., "Compare sales across regions", "What is the total profit?") to instantly generate dynamic data visualizations and statistical insights without writing any code.

## 🌟 Key Features

- **Conversational Queries**: Powered by a custom trained Machine Learning model (Scikit-Learn Naive Bayes) to classify user intent (Trend, Comparison, Aggregation, Profiling, Quality).
- **Context Memory**: Remembers context from the previous chat. If you omit a metric or intent in a follow-up question, the AI intelligently resolves it using recent chat history.
- **Dynamic Recommendations**: Recommends logical next-step analytical questions based on your active query intent and dataset columns.
- **Automated Visualizations**: Automatically generates trend lines, bar charts, pie charts, and multivariate scatter plots based on context using Plotly.
- **Data Quality Assessment**: Built-in modules to check missing values, duplicates, and outliers.

## 🛠️ Requirements & Dependencies

The project relies on the following major Python libraries. You can install them via `pip`:

```bash
pip install streamlit pandas plotly scikit-learn
```

### Detailed list of requirements:
- **`streamlit`** - Used for rendering the interactive dashboard and chatbot UI.
- **`pandas`** - Used for all underlying data manipulation, aggregation, and analytical queries.
- **`plotly`** - Used for generating beautiful, interactive charts (`plotly.express`).
- **`scikit-learn`** - Used in `nlp_processor.py` for TF-IDF Vectorization and Multinomial Naive Bayes intent classification.

*(Note: `re`, `pickle`, `os`, and `io` are also heavily used, but these are built-in Python libraries and do not require separate installation).*

## 🚀 How to Run

1. Ensure the required packages are installed.
2. Open your terminal and navigate to the project directory.
3. Run the application:
   ```bash
   streamlit run app.py
   ```
4. Access the dashboard in your browser via `http://localhost:8501`.
