import re
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
import pickle
import os

# Paths to cache the ML model
MODEL_PATH = "intent_classifier.pkl"
VECTORIZER_PATH = "tfidf_vectorizer.pkl"

def train_and_load_model():
    """Loads the ML intent classifier if it exists, or trains it dynamically."""
    if os.path.exists(MODEL_PATH) and os.path.exists(VECTORIZER_PATH):
        try:
            with open(MODEL_PATH, "rb") as model_file:
                clf = pickle.load(model_file)
            with open(VECTORIZER_PATH, "rb") as vec_file:
                vectorizer = pickle.load(vec_file)
            return clf, vectorizer
        except Exception:
            pass

    # Machine Learning Intent Dataset (Replaces Keyword mapping for core intents!)
    dataset = [
        # Profiling Intents
        ("summarize the data", "profiling"),
        ("show me statistics", "profiling"),
        ("describe the dataset", "profiling"),
        ("what are the data types", "profiling"),
        ("give me a profile of this data", "profiling"),
        
        # Quality Intents
        ("are there any missing values", "quality"),
        ("find duplicates in the data", "quality"),
        ("what is the data quality score", "quality"),
        ("detect outliers", "quality"),
        ("check data quality", "quality"),
        
        # Trend Intents
        ("how did sales change over the years", "trend"),
        ("what is the historical trajectory of profit", "trend"),
        ("show me the timeline of our expenses", "trend"),
        ("plot the progression from 2022 to 2024", "trend"),
        ("what does the curve look like for revenue over time", "trend"),
        ("yearly timeline", "trend"),
        ("trend map", "trend"),
        
        # Comparison Intents
        ("compare the performance across regions", "comparison"),
        ("who did better, north or south", "comparison"),
        ("show the differences between sectors", "comparison"),
        ("bar chart contrasting regional profit", "comparison"),
        ("which area holds the highest value against the others", "comparison"),
        ("put india and usa side by side", "comparison"),
        ("comparison matrix", "comparison"),
        
        # Aggregation Intents
        ("what is the total value", "aggregation"),
        ("give me the absolute sum", "aggregation"),
        ("find the highest peak", "aggregation"),
        ("calculate the mathematical average", "aggregation"),
        ("how much money did we make overall", "aggregation"),
        ("just give me the exact number for sales", "aggregation"),
        ("count the records", "aggregation"),
        ("how many items", "aggregation")
    ]
    
    df = pd.DataFrame(dataset, columns=["Text", "Intent"])
    
    # Text modeling utilizing TF-IDF vectors
    vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
    X = vectorizer.fit_transform(df["Text"])
    
    # Train the Multinomial Naive Bayes classifier
    clf = MultinomialNB()
    clf.fit(X, df["Intent"])
    
    # Cache to disk for instant loads moving forward
    with open(MODEL_PATH, "wb") as model_file:
        pickle.dump(clf, model_file)
    with open(VECTORIZER_PATH, "wb") as vec_file:
        pickle.dump(vectorizer, vec_file)
        
    return clf, vectorizer

# Initialize Model Pipeline Once
pipeline_clf, pipeline_vec = train_and_load_model()

def classify_intent_nlp(query: str) -> str:
    """Uses the Trained Scikit-Learn Model to classify contextual intent."""
    X_query = pipeline_vec.transform([query.lower()])
    prediction = pipeline_clf.predict(X_query)
    return prediction[0]

def process_query(query: str) -> dict:
    """
    Advanced NLP processor utilizing a Machine Learning Intent Classifier.
    """
    query_lower = query.lower()
    
    result = {
        "intent": classify_intent_nlp(query), # Dynamically classified using ML Engine!
        "filters": {},
        "metric": None,
        "operation": None
    }
    
    # Entity Extraction for specific math instructions
    operations = {
        "average": "average", "avg": "average", "mean": "average",
        "sum": "sum", "total": "sum",
        "max": "max", "highest": "max",
        "min": "min", "lowest": "min"
    }
    for word, op in operations.items():
        if re.search(rf'\b{word}\b', query_lower):
            result["operation"] = op
            break
                
    # Entity Extraction for Metrics
    metrics = ["sales", "profit", "revenue", "expenses", "cost"]
    for metric in metrics:
        if metric in query_lower:
            result["metric"] = metric
            break
            
    # Entity Extraction for Region Filters
    regions = ["north", "south", "east", "west", "usa", "europe", "asia", "uk", "india"]
    for region in regions:
        if region in query_lower:
            result["filters"]["region"] = region
            break
            
    # Entity Extraction for Year Filters
    year_match = re.search(r'\b(20\d{2})\b', query_lower)
    if year_match:
        result["filters"]["year"] = year_match.group(1)
        
    return result
